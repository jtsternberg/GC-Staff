# GC Staff #
**Contributors:**      jtsternberg  
**Donate link:**       http://dsgnwrks.pro  
**Tags:**  
**Requires at least:** 4.4  
**Tested up to:**      4.4  
**Stable tag:**        0.0.0  
**License:**           GPLv2  
**License URI:**       http://www.gnu.org/licenses/gpl-2.0.html  

## Description ##

Manage staff and staff users in WordPress

Please note: you will need to run composer install in order to fetch the dependenceis for this plugin/library, or you can download [the zip here](https://github.com/jtsternberg/GC-Staff/raw/master/gc-staff.zip).

## Installation ##

### Manual Installation ###

1. Upload the entire `/gc-staff` directory to the `/wp-content/plugins/` directory.
2. Activate GC Staff through the 'Plugins' menu in WordPress.

## Frequently Asked Questions ##


## Screenshots ##


## Changelog ##

### 0.0.0 ###
* First release

## Upgrade Notice ##

### 0.0.0 ###
First Release
