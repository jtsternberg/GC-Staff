# GC Staff Repo Assets #
http://dsgnwrks.pro
Copyright (c) 2016 jtsternberg
Licensed under the GPLv2 license.

Assets such as screenshots and banner for WordPress.org plugin repository listing.